#!/usr/bin/env python3
"""
waste_tracker.py — Autonomous scan-approach-pick state machine for RECLAIM.

This is the top-level autonomy node. It replaces Nav2 with a simpler
camera-driven approach:

  1. SCAN:     Rotate 360° in place, run YOLO on every frame, collect all
               detections with their 3D positions (via OAK-D stereo depth).
               After a full rotation, pick the nearest target.

  2. APPROACH: Drive toward the chosen target using visual servoing.
               Camera tracks the object — angular.z keeps it centered,
               linear.x drives forward. Slows down as it gets closer.

  3. ALIGN:    Stop driving. Fine-adjust heading so the target is centered
               and within the arm's reachable depth (150-450mm). Stabilize
               for a few frames to confirm position.

  4. PICK:     Stop motors. Execute the arm pickup sequence via serial
               commands through the PTY proxy (/tmp/teensy_arm). Arm does:
               home → prepick → pickup → grip → sort-to-bin → home.
               Then return to SCAN.

Data flow:
  ┌────────────────────────────────────────────────────┐
  │              waste_tracker node                     │
  │                                                    │
  │  OAK-D camera (internal, DepthAI v3 pipeline)     │
  │       ↓                                            │
  │  YOLO inference → 3D position (stereo depth)       │
  │       ↓                                            │
  │  State machine logic                               │
  │       ↓                                            │
  │  /cmd_vel (Twist) ──→ teensy_bridge ──→ motors     │
  │                                                    │
  │  /odom (Odometry) ←── teensy_bridge ←── encoders   │
  │                                                    │
  │  Arm commands ──→ /tmp/teensy_arm PTY ──→ Teensy   │
  │  (TeensyArmClient)                                 │
  │                                                    │
  │  /robot_state (String) ──→ for monitoring/debug    │
  └────────────────────────────────────────────────────┘

Prerequisites:
  - teensy_bridge must be running FIRST (owns /dev/ttyACM0, creates PTY)
  - OAK-D Lite on USB 3.0 port
  - YOLO model file on the MIC-711
  - Arm must be ARMed before autonomous pickup will work

Usage:
  # Terminal 1: start teensy_bridge (serial owner)
  ros2 launch reclaim_control teensy_bridge.launch.py

  # Terminal 2: start waste_tracker
  ros2 launch reclaim_bringup waste_tracker.launch.py

  # Or directly:
  ros2 run reclaim_bringup waste_tracker --ros-args \
      -p model_path:=models/waste_yolo11n_v3_best.engine \
      -p confidence:=0.35

Authors: Shady Siam, Issa Ahmed
"""

from __future__ import annotations

import math
import os
import sys
import threading
import time
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional, Tuple

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import String

# ---------------------------------------------------------------------------
# Add teensy_client to path so we can reuse TeensyArmClient for arm commands.
# This talks to /tmp/teensy_arm (PTY created by teensy_bridge), NOT the real
# serial port.  teensy_bridge forwards commands to the Teensy transparently.
# ---------------------------------------------------------------------------
_WS_SRC = os.path.join(os.path.dirname(__file__), '..', '..', '..',
                        'src', 'reclaim_control', 'scripts')
if os.path.isdir(_WS_SRC):
    sys.path.insert(0, os.path.abspath(_WS_SRC))

try:
    from teensy_client import TeensyArmClient
except ImportError:
    TeensyArmClient = None


# ══════════════════════════════════════════════════════════════════════
#  Constants & helpers (reused from guided_pickup.py)
# ══════════════════════════════════════════════════════════════════════

CLASS_NAMES = {
    0: 'plastic_bottle', 1: 'aluminum_can', 2: 'cardboard',
    3: 'plastic_container', 4: 'cup', 5: 'chip_bag',
    6: 'styrofoam_container', 7: 'napkin', 8: 'paper_bag',
    9: 'apple', 10: 'orange',
}

BIN_MAP = {
    'plastic_bottle': 'recyclable', 'aluminum_can': 'recyclable',
    'cardboard': 'recyclable', 'plastic_container': 'recyclable',
    'cup': 'landfill', 'chip_bag': 'landfill',
    'styrofoam_container': 'landfill', 'napkin': 'compost',
    'paper_bag': 'compost', 'apple': 'compost', 'orange': 'compost',
}

BIN_NUMBER = {'recyclable': 1, 'compost': 2, 'landfill': 3}

HOLD = -999  # firmware sentinel: keep current joint angle


class State(Enum):
    IDLE = auto()
    SCAN = auto()
    APPROACH = auto()
    ALIGN = auto()
    PICK = auto()


@dataclass
class Detection:
    """A single detected waste item with 3D position and pickup plan."""
    class_name: str
    confidence: float
    # Camera-frame position (mm)
    cam_x: float
    cam_y: float
    cam_z: float
    # Robot base-frame position (mm): x=forward, y=left, z=up
    robot_x: float
    robot_y: float
    robot_z: float
    # Pixel center in image
    cx_px: int
    cy_px: int
    # Bounding box size (for grip strategy)
    bbox_w: float
    bbox_h: float

    @property
    def distance_mm(self) -> float:
        """Horizontal distance from robot to object (mm)."""
        return math.sqrt(self.robot_x ** 2 + self.robot_y ** 2)

    @property
    def bearing_rad(self) -> float:
        """Angle from robot forward axis to object (rad). + = left."""
        return math.atan2(self.robot_y, self.robot_x)


# ── Camera-to-robot coordinate transform ──────────────────────────────

def camera_to_robot(x_cam_mm, y_cam_mm, z_cam_mm,
                    tilt_deg: float = 15.0,
                    tx_mm: float = 0.0,
                    ty_mm: float = 0.0,
                    tz_mm: float = -150.0) -> Tuple[float, float, float]:
    """Transform camera optical frame → robot base frame.

    Camera optical frame: Z = forward, X = right, Y = down.
    Robot base frame:     X = forward, Y = left,  Z = up.

    The camera is mounted with a downward tilt and offset from base_link.

    Args:
        x_cam_mm, y_cam_mm, z_cam_mm: position in camera optical frame (mm)
        tilt_deg: camera downward tilt angle (degrees)
        tx/ty/tz_mm: camera position offset from base_link origin (mm)

    Returns:
        (x_robot, y_robot, z_robot) in robot base frame (mm)
    """
    # Step 1: camera optical → camera link (axis swap)
    x_link = float(z_cam_mm)      # depth → forward
    y_link = -float(x_cam_mm)     # right → left
    z_link = -float(y_cam_mm)     # down  → up

    # Step 2: undo camera tilt (rotation about Y axis)
    theta = math.radians(tilt_deg)
    cos_t, sin_t = math.cos(theta), math.sin(theta)
    x_rot = x_link * cos_t + z_link * sin_t
    y_rot = y_link
    z_rot = -x_link * sin_t + z_link * cos_t

    # Step 3: translate by camera mounting offset
    return (x_rot + tx_mm, y_rot + ty_mm, z_rot + tz_mm)


# ── Depth sampling from stereo depth frame ────────────────────────────

def get_depth_for_bbox(depth_frame, x1, y1, x2, y2,
                       intrinsics=None) -> Tuple[float, float, float]:
    """Extract median depth and 3D camera-frame position for a bbox.

    Uses the center 50% of the bounding box to avoid edge noise.
    Returns (x_mm, y_mm, z_mm) in camera optical frame, or (0,0,0) on failure.
    """
    h, w = depth_frame.shape[:2]
    x1, y1 = max(0, int(x1)), max(0, int(y1))
    x2, y2 = min(w, int(x2)), min(h, int(y2))
    if x2 <= x1 or y2 <= y1:
        return 0.0, 0.0, 0.0

    cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
    bw, bh = (x2 - x1) // 4, (y2 - y1) // 4
    roi = depth_frame[max(0, cy - bh):min(h, cy + bh),
                      max(0, cx - bw):min(w, cx + bw)]
    if roi.size == 0:
        return 0.0, 0.0, 0.0

    valid = roi[(roi > 100) & (roi < 10000)]  # 10cm – 10m
    if valid.size == 0:
        return 0.0, 0.0, 0.0

    z_mm = float(np.median(valid))

    if intrinsics is not None:
        fx, fy = float(intrinsics[0][0]), float(intrinsics[1][1])
        cx_cam, cy_cam = float(intrinsics[0][2]), float(intrinsics[1][2])
    else:
        fx, fy = 500.0, 500.0
        cx_cam, cy_cam = 320.0, 240.0

    x_mm = (cx - cx_cam) * z_mm / fx
    y_mm = (cy - cy_cam) * z_mm / fy
    return x_mm, y_mm, z_mm


# ── Grip strategy (from guided_pickup.py) ─────────────────────────────

def determine_grip(class_name: str, bbox_w: float, bbox_h: float
                   ) -> Tuple[int, int]:
    """Choose grip angle (J6) and wrist orientation (J5).

    Returns (grip_angle_deg, j5_angle_deg).
    """
    small = ['aluminum_can', 'apple', 'orange']
    large = ['cardboard', 'paper_bag', 'styrofoam_container']

    if class_name in small:
        grip = 35
    elif class_name in large:
        grip = 55
    else:
        grip = 45

    # Wrist orientation from aspect ratio
    if bbox_w > bbox_h * 1.3:
        j5 = -60   # horizontal
    elif bbox_h > bbox_w * 1.3:
        j5 = 26    # vertical
    else:
        j5 = -60   # default

    return grip, j5


def build_pickup_commands(j1: float, j5: int, grip_angle: int,
                          bin_n: int) -> List[str]:
    """Build serial command sequence for a pickup cycle.

    Overrides J1 (base rotation) and J5 (wrist orient) for the descent,
    then uses firmware-taught bin poses for sorting.
    """
    cmds = [
        f"SET {j1:.1f} 133 65 -15 {j5} 0 T 750",        # home
        f"SET {j1:.1f} 75 65 20 {j5} 0 T 700",           # prepick
        f"SET {j1:.1f} 65 65 20 {j5} 0 T 700",           # pickup (open)
        f"GRIP {grip_angle} T 500",                        # grip
        "__PAUSE_200__",
        f"SET {j1:.1f} 75 65 20 {j5} {HOLD} T 700",      # prepick_carry
        f"SET {j1:.1f} 133 65 -15 {j5} {HOLD} T 700",    # home_carry
        f"POSE bin{bin_n}_pre T 1000",                     # bin approach
        f"POSE bin{bin_n}_drop T 700",                     # drop
        f"POSE bin{bin_n}_pre T 700",                      # retract
        "POSE home T 1000",                                # return home
    ]
    return cmds


# ══════════════════════════════════════════════════════════════════════
#  WasteTracker ROS2 Node
# ══════════════════════════════════════════════════════════════════════

class WasteTracker(Node):
    def __init__(self):
        super().__init__('waste_tracker')

        # ── ROS Parameters ────────────────────────────────────────────
        self.declare_parameter('model_path', 'yolov8n.pt')
        self.declare_parameter('confidence', 0.35)
        self.declare_parameter('pty_path', '/tmp/teensy_arm')

        # Camera transform parameters
        self.declare_parameter('camera_tilt_deg', 15.0)
        self.declare_parameter('camera_tx_mm', 0.0)
        self.declare_parameter('camera_ty_mm', 0.0)
        self.declare_parameter('camera_tz_mm', -150.0)

        # SCAN parameters
        self.declare_parameter('scan_angular_vel', 0.3)     # rad/s rotation speed
        self.declare_parameter('scan_full_rotation', 6.28)   # ~2*pi rad

        # APPROACH parameters
        self.declare_parameter('approach_linear_vel', 0.12)  # m/s max forward speed
        self.declare_parameter('approach_angular_gain', 0.003)  # px offset → rad/s
        self.declare_parameter('approach_linear_gain', 0.0003)  # depth mm → m/s
        self.declare_parameter('approach_stop_distance_mm', 400.0)  # stop when this close

        # ALIGN parameters
        self.declare_parameter('align_pixel_tolerance', 30)  # px from image center
        self.declare_parameter('align_angular_vel', 0.15)    # rad/s for fine adjustment
        self.declare_parameter('align_stable_frames', 5)     # frames target must be stable
        self.declare_parameter('align_min_depth_mm', 150.0)  # arm reach min
        self.declare_parameter('align_max_depth_mm', 450.0)  # arm reach max

        # Obstacle avoidance (depth-based)
        self.declare_parameter('obstacle_min_depth_mm', 300.0)  # stop if anything closer

        # ── Read parameters ───────────────────────────────────────────
        self.model_path = self.get_parameter('model_path').value
        self.confidence = self.get_parameter('confidence').value
        self.pty_path = self.get_parameter('pty_path').value

        self.cam_tilt = self.get_parameter('camera_tilt_deg').value
        self.cam_tx = self.get_parameter('camera_tx_mm').value
        self.cam_ty = self.get_parameter('camera_ty_mm').value
        self.cam_tz = self.get_parameter('camera_tz_mm').value

        self.scan_vel = self.get_parameter('scan_angular_vel').value
        self.scan_target = self.get_parameter('scan_full_rotation').value

        self.approach_max_v = self.get_parameter('approach_linear_vel').value
        self.approach_w_gain = self.get_parameter('approach_angular_gain').value
        self.approach_v_gain = self.get_parameter('approach_linear_gain').value
        self.approach_stop_dist = self.get_parameter('approach_stop_distance_mm').value

        self.align_px_tol = self.get_parameter('align_pixel_tolerance').value
        self.align_w = self.get_parameter('align_angular_vel').value
        self.align_stable_needed = self.get_parameter('align_stable_frames').value
        self.align_min_depth = self.get_parameter('align_min_depth_mm').value
        self.align_max_depth = self.get_parameter('align_max_depth_mm').value

        self.obstacle_min = self.get_parameter('obstacle_min_depth_mm').value

        # ── State machine ─────────────────────────────────────────────
        self.state = State.IDLE
        self.scan_start_yaw = 0.0
        self.scan_accumulated = 0.0
        self.scan_detections: List[Detection] = []
        self.current_target: Optional[Detection] = None
        self.align_stable_count = 0
        self.current_yaw = 0.0
        self.prev_yaw = None
        self.items_collected = 0

        # ── Camera / YOLO (run in background thread) ──────────────────
        self.camera_lock = threading.Lock()
        self.latest_detections: List[Detection] = []
        self.obstacle_ahead = False
        self.camera_ready = False
        self.camera_frame_count = 0
        self.image_width = 640
        self.image_height = 480

        # ── Arm client (via PTY proxy) ────────────────────────────────
        self.arm: Optional[TeensyArmClient] = None

        # ── ROS publishers / subscribers ──────────────────────────────
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.state_pub = self.create_publisher(String, '/robot_state', 10)

        self.create_subscription(Odometry, '/odom', self._odom_cb, 10)

        # ── Main loop timer (20 Hz state machine tick) ────────────────
        self.create_timer(0.05, self._tick)

        # ── State publish timer (2 Hz) ────────────────────────────────
        self.create_timer(0.5, self._publish_state)

        # ── Start camera thread ───────────────────────────────────────
        self.camera_thread = threading.Thread(target=self._camera_loop, daemon=True)
        self.camera_thread.start()

        self.get_logger().info(
            f'WasteTracker initialized: model={self.model_path}, '
            f'conf={self.confidence}, pty={self.pty_path}'
        )
        self.get_logger().info('Waiting for camera to initialize...')

    # ==================================================================
    #  Odometry callback — track robot heading for SCAN rotation
    # ==================================================================

    def _odom_cb(self, msg: Odometry):
        """Extract yaw from odometry quaternion."""
        q = msg.pose.pose.orientation
        # Yaw from quaternion (robot is 2D, only z rotation matters)
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.current_yaw = math.atan2(siny, cosy)

    # ==================================================================
    #  Camera + YOLO thread (runs independently at camera FPS)
    # ==================================================================

    def _camera_loop(self):
        """Background thread: capture frames, run YOLO, update detections.

        This runs at ~15-30 FPS depending on the model. The state machine
        reads self.latest_detections from the main timer callback.
        """
        import depthai as dai
        from ultralytics import YOLO

        is_engine = self.model_path.endswith(('.engine', '.trt'))

        self.get_logger().info(f'Loading YOLO model: {self.model_path}')
        model = YOLO(self.model_path, task='detect')
        self.get_logger().info('YOLO model loaded.')

        with dai.Pipeline() as pipeline:
            # ── RGB camera ──
            cam = pipeline.create(dai.node.Camera).build(
                dai.CameraBoardSocket.CAM_A)
            rgb_out = cam.requestOutput(
                (self.image_width, self.image_height)).createOutputQueue()

            # ── Stereo depth (aligned to RGB) ──
            stereo = pipeline.create(dai.node.StereoDepth).build(
                autoCreateCameras=True)
            stereo.setDefaultProfilePreset(
                dai.node.StereoDepth.PresetMode.DEFAULT)
            stereo.setDepthAlign(dai.CameraBoardSocket.CAM_A)
            stereo.setOutputSize(self.image_width, self.image_height)
            stereo.setLeftRightCheck(True)
            stereo.setSubpixel(True)
            stereo.setExtendedDisparity(True)
            depth_out = stereo.depth.createOutputQueue()

            pipeline.start()
            self.get_logger().info('OAK-D pipeline started.')

            # Read factory intrinsics
            calib = pipeline.getDefaultDevice().readCalibration()
            intrinsics = np.array(calib.getCameraIntrinsics(
                dai.CameraBoardSocket.CAM_A,
                self.image_width, self.image_height))
            self.get_logger().info(
                f'Intrinsics: fx={intrinsics[0][0]:.1f}, '
                f'fy={intrinsics[1][1]:.1f}, '
                f'cx={intrinsics[0][2]:.1f}, '
                f'cy={intrinsics[1][2]:.1f}')

            self.camera_ready = True
            self.get_logger().info('Camera ready. Entering IDLE state.')

            img_cx = self.image_width / 2.0

            while pipeline.isRunning() and rclpy.ok():
                rgb_data = rgb_out.get()
                frame = rgb_data.getCvFrame()

                depth_data = depth_out.tryGet()
                depth_frame = depth_data.getCvFrame() if depth_data else None

                # ── YOLO inference ──
                results = model(frame, conf=self.confidence, verbose=False)
                if is_engine:
                    results[0].names = CLASS_NAMES
                boxes = results[0].boxes

                detections: List[Detection] = []

                if len(boxes) > 0 and depth_frame is not None:
                    if depth_frame.shape[:2] != (self.image_height,
                                                  self.image_width):
                        depth_frame = cv2.resize(
                            depth_frame,
                            (self.image_width, self.image_height),
                            interpolation=cv2.INTER_NEAREST)

                    for box in boxes:
                        cls_id = int(box.cls.cpu().numpy()[0])
                        conf = float(box.conf.cpu().numpy()[0])
                        name = CLASS_NAMES.get(cls_id, f'class{cls_id}')
                        x1, y1, x2, y2 = box.xyxy.cpu().numpy()[0]

                        cam_x, cam_y, cam_z = get_depth_for_bbox(
                            depth_frame, x1, y1, x2, y2, intrinsics)
                        if cam_z < 1:
                            continue

                        robot_x, robot_y, robot_z = camera_to_robot(
                            cam_x, cam_y, cam_z,
                            self.cam_tilt, self.cam_tx,
                            self.cam_ty, self.cam_tz)

                        cx_px = int((x1 + x2) / 2)
                        cy_px = int((y1 + y2) / 2)
                        bbox_w = float(x2 - x1)
                        bbox_h = float(y2 - y1)

                        detections.append(Detection(
                            class_name=name, confidence=conf,
                            cam_x=cam_x, cam_y=cam_y, cam_z=cam_z,
                            robot_x=robot_x, robot_y=robot_y,
                            robot_z=robot_z,
                            cx_px=cx_px, cy_px=cy_px,
                            bbox_w=bbox_w, bbox_h=bbox_h,
                        ))

                # ── Obstacle check (center strip of depth image) ──
                obstacle = False
                if depth_frame is not None:
                    # Check a vertical strip in the center 20% of the image
                    strip_l = int(self.image_width * 0.4)
                    strip_r = int(self.image_width * 0.6)
                    center_strip = depth_frame[:, strip_l:strip_r]
                    valid_center = center_strip[center_strip > 0]
                    if valid_center.size > 0:
                        min_depth = float(np.percentile(valid_center, 5))
                        obstacle = min_depth < self.obstacle_min

                # ── Update shared state (thread-safe) ──
                with self.camera_lock:
                    self.latest_detections = detections
                    self.obstacle_ahead = obstacle
                    self.camera_frame_count += 1

    # ==================================================================
    #  Main state machine tick (20 Hz)
    # ==================================================================

    def _tick(self):
        """Main control loop — runs at 20 Hz from ROS timer."""
        if not self.camera_ready:
            return

        # Auto-transition from IDLE to SCAN once camera is ready
        if self.state == State.IDLE:
            self._enter_scan()
            return

        if self.state == State.SCAN:
            self._tick_scan()
        elif self.state == State.APPROACH:
            self._tick_approach()
        elif self.state == State.ALIGN:
            self._tick_align()
        elif self.state == State.PICK:
            pass  # pickup runs synchronously in a thread

    # ── SCAN state ────────────────────────────────────────────────────

    def _enter_scan(self):
        self.state = State.SCAN
        self.scan_start_yaw = self.current_yaw
        self.scan_accumulated = 0.0
        self.prev_yaw = self.current_yaw
        self.scan_detections.clear()
        self.get_logger().info('=== SCAN: starting 360° rotation ===')

    def _tick_scan(self):
        """Rotate in place, collect detections, stop after full rotation."""
        # Track accumulated rotation using yaw deltas (handles wrapping)
        if self.prev_yaw is not None:
            delta = self.current_yaw - self.prev_yaw
            # Normalize delta to [-pi, pi] for wrap-around
            delta = math.atan2(math.sin(delta), math.cos(delta))
            self.scan_accumulated += abs(delta)
        self.prev_yaw = self.current_yaw

        # Collect detections from the camera thread
        with self.camera_lock:
            frame_dets = list(self.latest_detections)

        for det in frame_dets:
            # De-duplicate: skip if we already have a detection of the
            # same class within 200mm (same object seen from similar angle)
            is_dup = False
            for existing in self.scan_detections:
                if (existing.class_name == det.class_name and
                        abs(existing.cam_z - det.cam_z) < 200):
                    # Keep the higher-confidence one
                    if det.confidence > existing.confidence:
                        self.scan_detections.remove(existing)
                    else:
                        is_dup = True
                    break
            if not is_dup:
                self.scan_detections.append(det)

        # Publish rotation command
        twist = Twist()
        twist.angular.z = self.scan_vel
        self.cmd_vel_pub.publish(twist)

        # Check if full rotation is complete
        if self.scan_accumulated >= self.scan_target:
            self._stop_motors()

            if not self.scan_detections:
                self.get_logger().info(
                    'SCAN complete — no targets found. Rescanning...')
                self._enter_scan()  # rescan
                return

            # Sort by distance, pick nearest
            self.scan_detections.sort(key=lambda d: d.distance_mm)
            self.current_target = self.scan_detections[0]

            self.get_logger().info(
                f'SCAN complete — {len(self.scan_detections)} targets found. '
                f'Nearest: {self.current_target.class_name} '
                f'@ {self.current_target.distance_mm:.0f}mm')

            self._enter_approach()

    # ── APPROACH state ────────────────────────────────────────────────

    def _enter_approach(self):
        self.state = State.APPROACH
        self.get_logger().info(
            f'=== APPROACH: driving toward {self.current_target.class_name} ===')

    def _tick_approach(self):
        """Drive toward target using visual servoing.

        Angular: proportional control to keep target centered in image.
        Linear:  proportional to distance, slowing as we get closer.
        """
        # Check for obstacles
        with self.camera_lock:
            obstacle = self.obstacle_ahead
            frame_dets = list(self.latest_detections)

        if obstacle:
            self._stop_motors()
            self.get_logger().warn('APPROACH: obstacle detected — stopping')
            # For now, just wait. Could add avoidance logic later.
            return

        # Find the target in current detections (match by class name,
        # pick the one closest to where we expect it)
        target_det = self._find_target_in_detections(frame_dets)

        if target_det is None:
            # Target lost — stop and rescan
            self._stop_motors()
            self.get_logger().warn('APPROACH: target lost — rescanning')
            self._enter_scan()
            return

        # Update current target with latest position
        self.current_target = target_det

        # ── Visual servoing ──
        img_cx = self.image_width / 2.0
        pixel_offset = target_det.cx_px - img_cx  # positive = target is right

        # Angular: steer to center the target (negative because right offset
        # needs left turn = positive angular.z)
        angular_z = -self.approach_w_gain * pixel_offset

        # Linear: proportional to distance, capped at max
        dist = target_det.cam_z  # use camera depth directly (mm)
        if dist <= self.approach_stop_dist:
            # Close enough — transition to ALIGN
            self._stop_motors()
            self._enter_align()
            return

        linear_x = min(self.approach_max_v,
                       self.approach_v_gain * (dist - self.approach_stop_dist))
        linear_x = max(0.0, linear_x)  # no reversing

        twist = Twist()
        twist.linear.x = linear_x
        twist.angular.z = angular_z
        self.cmd_vel_pub.publish(twist)

    # ── ALIGN state ───────────────────────────────────────────────────

    def _enter_align(self):
        self.state = State.ALIGN
        self.align_stable_count = 0
        self.get_logger().info('=== ALIGN: fine-positioning for pickup ===')

    def _tick_align(self):
        """Fine-adjust heading so target is centered and within reach."""
        with self.camera_lock:
            frame_dets = list(self.latest_detections)

        target_det = self._find_target_in_detections(frame_dets)

        if target_det is None:
            self._stop_motors()
            self.get_logger().warn('ALIGN: target lost — rescanning')
            self._enter_scan()
            return

        self.current_target = target_det
        img_cx = self.image_width / 2.0
        pixel_offset = target_det.cx_px - img_cx

        # Check if centered
        if abs(pixel_offset) > self.align_px_tol:
            # Rotate to center
            direction = -1.0 if pixel_offset > 0 else 1.0
            twist = Twist()
            twist.angular.z = direction * self.align_w
            self.cmd_vel_pub.publish(twist)
            self.align_stable_count = 0
            return

        # Centered — stop motors
        self._stop_motors()

        # Check depth is within arm reach
        depth = target_det.cam_z
        if depth < self.align_min_depth or depth > self.align_max_depth:
            # Too close or too far — nudge forward/backward
            twist = Twist()
            if depth > self.align_max_depth:
                twist.linear.x = 0.05   # creep forward
            else:
                twist.linear.x = -0.05  # back up
            self.cmd_vel_pub.publish(twist)
            self.align_stable_count = 0
            return

        # Target is centered AND in reach — count stable frames
        self.align_stable_count += 1
        if self.align_stable_count >= self.align_stable_needed:
            self.get_logger().info(
                f'ALIGN: locked on {target_det.class_name} '
                f'@ {depth:.0f}mm, offset={pixel_offset:.0f}px')
            self._enter_pick()

    # ── PICK state ────────────────────────────────────────────────────

    def _enter_pick(self):
        self.state = State.PICK
        self._stop_motors()
        self.get_logger().info(
            f'=== PICK: picking up {self.current_target.class_name} ===')

        # Run pickup in a thread so we don't block the ROS executor
        pick_thread = threading.Thread(target=self._execute_pick, daemon=True)
        pick_thread.start()

    def _execute_pick(self):
        """Execute the full arm pickup sequence (blocking).

        Connects to arm via PTY, sends pickup commands, waits for completion.
        """
        target = self.current_target
        if target is None:
            self.get_logger().error('PICK: no target — returning to SCAN')
            self._enter_scan()
            return

        # ── Determine pickup parameters ──
        bin_name = BIN_MAP.get(target.class_name, 'landfill')
        bin_n = BIN_NUMBER.get(bin_name, 1)
        grip_angle, j5_angle = determine_grip(
            target.class_name, target.bbox_w, target.bbox_h)

        # Compute J1 rotation to face the object
        # robot_x = forward, robot_y = left → bearing angle
        base_j1 = -32.0  # default home J1 (from guided_pickup.py)
        if abs(target.robot_x) > 1.0:
            j1_delta = math.degrees(math.atan2(-target.robot_y, target.robot_x))
        else:
            j1_delta = 0.0
        j1_adj = max(-148.0, min(148.0, base_j1 + j1_delta))

        self.get_logger().info(
            f'PICK plan: {target.class_name} → bin {bin_n} ({bin_name}), '
            f'J1={j1_adj:.1f}, grip={grip_angle}, J5={j5_angle}')

        # ── Connect to arm via PTY ──
        if TeensyArmClient is None:
            self.get_logger().error('PICK: TeensyArmClient not available')
            self._enter_scan()
            return

        try:
            arm = TeensyArmClient(self.pty_path, baud=115200, boot_wait_s=0.5)
            arm.open()
        except Exception as e:
            self.get_logger().error(f'PICK: failed to connect to arm: {e}')
            self._enter_scan()
            return

        try:
            # Build and execute command sequence
            commands = build_pickup_commands(j1_adj, j5_angle, grip_angle, bin_n)

            success = True
            for cmd in commands:
                if cmd == "__PAUSE_200__":
                    time.sleep(0.2)
                    continue
                result = arm.command(cmd, wait_for_done=True,
                                     timeout_s=12.0, echo=True)
                if result.timed_out:
                    self.get_logger().error(f'PICK: timeout on {cmd}')
                    arm.command("STOP", wait_for_done=False, timeout_s=2.0)
                    arm.command("POSE home T 1000", wait_for_done=True,
                                timeout_s=10.0)
                    success = False
                    break

            if success:
                self.items_collected += 1
                self.get_logger().info(
                    f'PICK: SUCCESS — {target.class_name} → {bin_name}. '
                    f'Total collected: {self.items_collected}')
            else:
                self.get_logger().warn('PICK: FAILED — returning to scan')

        finally:
            arm.close()

        # Return to scanning
        self._enter_scan()

    # ==================================================================
    #  Helper methods
    # ==================================================================

    def _find_target_in_detections(self, detections: List[Detection]
                                    ) -> Optional[Detection]:
        """Find the tracked target in the latest detection list.

        Matches by class name. If multiple of the same class, picks the
        one closest to the expected pixel position.
        """
        if not detections or self.current_target is None:
            return None

        target_class = self.current_target.class_name
        candidates = [d for d in detections if d.class_name == target_class]

        if not candidates:
            # Fallback: accept any detection (target may have been
            # reclassified at a different angle)
            candidates = detections

        if not candidates:
            return None

        # Pick the one closest to where we last saw the target (pixel space)
        ref_cx = self.current_target.cx_px
        ref_cy = self.current_target.cy_px
        candidates.sort(key=lambda d:
                        (d.cx_px - ref_cx) ** 2 + (d.cy_px - ref_cy) ** 2)
        return candidates[0]

    def _stop_motors(self):
        """Publish zero velocity."""
        self.cmd_vel_pub.publish(Twist())

    def _publish_state(self):
        """Publish current state for monitoring."""
        msg = String()
        info = f'{self.state.name}'
        if self.state == State.SCAN:
            progress = min(100, int(
                self.scan_accumulated / self.scan_target * 100))
            info += f' ({progress}%, {len(self.scan_detections)} found)'
        elif self.state in (State.APPROACH, State.ALIGN) and self.current_target:
            info += (f' → {self.current_target.class_name} '
                     f'@ {self.current_target.cam_z:.0f}mm')
        elif self.state == State.PICK and self.current_target:
            info += f' {self.current_target.class_name}'
        info += f' | collected: {self.items_collected}'
        msg.data = info
        self.state_pub.publish(msg)

    def destroy_node(self):
        self._stop_motors()
        super().destroy_node()


# ══════════════════════════════════════════════════════════════════════
#  Entry point
# ══════════════════════════════════════════════════════════════════════

def main(args=None):
    rclpy.init(args=args)
    node = WasteTracker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
